﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class PlayerDied : MonoBehaviour {

	public delegate void EndGame();
	public static event EndGame endGame;

	void PlayerDiedEndGame() {
		if (endGame != null) 
			endGame ();

		Destroy (gameObject);
		SceneManager.LoadScene(2);
	}
	
	void OnTriggerEnter2D(Collider2D target) {
		if (target.tag == "Collector") {
			PlayerDiedEndGame();
		}
	}

	void OnCollisionEnter2D(Collision2D target) {
		if (target.gameObject.tag == "Zombie") {
			PlayerDiedEndGame();
			SceneManager.LoadScene(2);
		}
		if(target.gameObject.tag == "Died Collider"){
			Destroy(this.gameObject);
		}
	}


} // PlayerDied








































