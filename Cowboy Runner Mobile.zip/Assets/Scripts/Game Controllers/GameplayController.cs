﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;
public class GameplayController : MonoBehaviour {
	public Text scoreText;
	public float scoreAmount;
	public float scoreIncreasedPerSecond;
	public void Start(){
		scoreAmount = 0f;
		scoreIncreasedPerSecond = 1f;
	}
	public void Update(){
		scoreText.text = (int)scoreAmount + " " + "M";
		scoreAmount += scoreIncreasedPerSecond * Time.deltaTime;
	}
} //GameplayController
