using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.AI;
using UnityEngine.Audio;
using UnityEngine.Video;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine;

public class LoseGameManager : MonoBehaviour
{
    public void Start()
    {

    }
    public void PlayAgain()
    {
        SceneManager.LoadScene(1);
    }    
    public void MainMenu()
    {
        SceneManager.LoadScene(0);
    }
}
